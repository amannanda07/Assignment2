﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assigment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            // button components
            // declaring variables
            // declaring variable type
            double total = 0;
            double subtotal = 0;
            double tax = 0;
            int qty = int.Parse(txtbx1.Text);
            int qty2 = int.Parse(txtbx2.Text);
            int qty3 = int.Parse(txtbx3.Text);
            double breakfast = 0;
            double lunch = 0;
            double dinner = 0;
            double sub1 = 0;
            double sub2 = 0;
            double sub3 = 0;
           

            // applying loop
            if (cb1.SelectedIndex == 0)
            {
                breakfast = 3.95 * qty;
            }
            if (cb1.SelectedIndex == 1)
            {
               breakfast = 10.95 * qty;
            }
            if (cb1.SelectedIndex == 2)
            {
                breakfast = 11.95 * qty;
            }
            subtotal = breakfast + lunch + dinner;


            if (cb2.SelectedIndex == 0)
            {
                lunch = 3.95 * qty;
            }
            if (cb2.SelectedIndex == 1)
            {
                lunch = 10.95 * qty;
            }
            if (cb2.SelectedIndex == 2)
            {
                lunch = 11.95 * qty;
            }
            subtotal = breakfast + lunch + dinner;
            if (cb3.SelectedIndex == 0)
            {
                dinner = 3.95 * qty;
            }
            if (cb3.SelectedIndex == 1)
            {
                dinner = 10.95 * qty;
            }
            if (cb3.SelectedIndex == 2)
            {
                dinner = 11.95 * qty;
            }
            subtotal = breakfast + lunch + dinner;

            // applying value
            lbl1.Text = Convert.ToString(subtotal);

            tax = subtotal * 13;

            lbl2.Text = Convert.ToString(tax);

            total = subtotal + tax;

            lbl3.Text = Convert.ToString(total);
        }

        private void cb1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // check index value and tell if incorrect
            if (cb1.SelectedIndex < -1)
            {
                lbl4.Text = "Invalid meal selection.";
                //done;
            }
        }

        private void cb2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // check index value and tell if incorrect
            if (cb2.SelectedIndex < -1)
            {
                lbl5.Text = "Invalid meal selection.";
                //done;
            }
        }

        private void cb3_SelectedIndexChanged(object sender, EventArgs e)
        {
            // check index value and tell if incorrect
            if (cb3.SelectedIndex < -1)
            {
                lbl6.Text = "Invalid meal selection.";
                //done;
            }
        }

        private void txtbx1_TextChanged(object sender, EventArgs e)
        {
            // setting text box value to only accept numeric
            if (System.Text.RegularExpressions.Regex.IsMatch(txtbx1.Text, " ^ [0-9]"))
            {
                txtbx1.Text = "";
                lbl4.Text = "Invalid Quantity";
            }
        }

        private void txtbx2_TextChanged(object sender, EventArgs e)
        {
            // setting text box value to only accept numeric
            if (System.Text.RegularExpressions.Regex.IsMatch(txtbx2.Text, " ^ [0-9]"))
            {
                txtbx2.Text = "";
                lbl5.Text = "Invalid Quantity";
            }
        }

        private void txtbx3_TextChanged(object sender, EventArgs e)
        {
            // setting text box value to only accept numeric
            if (System.Text.RegularExpressions.Regex.IsMatch(txtbx3.Text, " ^ [0-9]"))
            {
                txtbx3.Text = "";
                lbl6.Text = "Invalid Quantity";
            }
        }

        private void lbl2_Click(object sender, EventArgs e)
        {

        }

        private void lbl5_Click(object sender, EventArgs e)
        {

        }
    }
}
